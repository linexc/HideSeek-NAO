
"use strict";

let move_direction = require('./move_direction.js')
let aruco_coordinate = require('./aruco_coordinate.js')
let detect_process = require('./detect_process.js')

module.exports = {
  move_direction: move_direction,
  aruco_coordinate: aruco_coordinate,
  detect_process: detect_process,
};
